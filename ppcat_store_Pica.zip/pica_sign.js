// Pica signature generator


function Oe(e, t) {

    const a = Array.from(
        {length:e.length},
        (v,i)=>i
    );

    let o = 0;

    for(let r=0;r<t.length;r++){
        o += t.charCodeAt(r);
    }


    for(let r=a.length-1;r>0;r--){

        o=(9301*o+49297)%233280;

        const x=o%(r+1);

        [
            a[r],
            a[x]
        ]=[
            a[x],
            a[r]
        ];
    }


    const out=new Array(e.length);

    for(let i=0;i<e.length;i++){
        out[i]=e[a[i]];
    }

    return out.join("");
}



function Ue(e){

    try{

        let a=Oe(
            atob(e),
            "PicaWeb2025"
        );


        let o=a
        .split("")
        .map(
            c=>String.fromCharCode(
                c.charCodeAt(0)^42
            )
        )
        .join("");


        return atob(o);

    }catch(err){

        return "";

    }
}



// salt

const PICA_SALT =
Ue(
"b397e2wXZHtgb2RvUBh7bnB+bnt8bEEfZ2xSQUFtY0F4G3h4bWhzeA=="
);


// secret

const PICA_KEY =
Ue(
"aGh+G0dwfHpGUGRmYGxrGUFsZmRyGUMZa19kfUxfRxMfXGAaGxNBbmBhZRpMQUFma20Bbn58YElIYGQTbGdsQkxrfEd8X3xueBocH1JQf2RpSG9B"
);



function nonce(){

    let n=localStorage.getItem(
        "nonce"
    );

    if(!n){

        const chars=
        "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678";


        n="";

        for(let i=0;i<32;i++){

            n+=chars[
                Math.floor(
                    Math.random()*48
                )
            ];

        }


        n=n.toLowerCase();

        localStorage.setItem(
            "nonce",
            n
        );
    }


    return n;
}



async function signature(
    path,
    time,
    quality="medium"
){

    let msg=
    (
        path
        +
        time
        +
        nonce()
        +
        quality
        +
        PICA_SALT
    )
    .toLowerCase();



    const encoder=
    new TextEncoder();


    const key=
    encoder.encode(
        PICA_KEY
    );


    const cryptoKey=
    await crypto.subtle.importKey(

        "raw",

        key,

        {
            name:"HMAC",
            hash:"SHA-256"
        },

        false,

        ["sign"]

    );



    const sig=
    await crypto.subtle.sign(

        "HMAC",

        cryptoKey,

        encoder.encode(msg)

    );


    return Array.from(
        new Uint8Array(sig)
    )
    .map(
        x=>x.toString(16).padStart(2,"0")
    )
    .join("");

}



async function beforeRequest(req){

    const time=
    Math.floor(
        Date.now()/1000
    ).toString();


    req.header.time=time;

    req.header.nonce=nonce();

    req.header["image-quality"]="medium";


    req.header.signature=
    await signature(
        req.path,
        time,
        "medium"
    );


    return req;
}