function picaSecret(){

    return "C69BAF41DA5ABD1FFEDC6D2FEA56B";

}


function picaKey(){

    return "~d}$Q7$eIni=V)9\\RK/P.RM4;9[7|@/CA}b~OW!3?EV`:<>M7pddUBL5n|0/*Cn";

}